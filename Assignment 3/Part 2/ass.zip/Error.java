/* You must use these strings to print error messages in the Table class */
public class Error {
	public static final String Err1 = "Table is empty";
	public static final String Err2 = "No indexes found";
	public static final String Err3 = "No suitable index found";
	public static final String Err4 = "Record(s) not found"; // 
	public static final String Err5 = "Column name not found";
}